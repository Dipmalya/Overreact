import React from 'react';
import ReactDOM from 'react-dom';
import Parent from './Parent';

ReactDOM.render(
    <div>
        <Parent/>
    </div>
    , document.getElementById('root'));
