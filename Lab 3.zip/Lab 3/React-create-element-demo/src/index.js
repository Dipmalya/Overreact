import React from 'react';
import ReactDOM from 'react-dom';
import Welcome from './App';

ReactDOM.render(<Welcome/>, document.getElementById('root'));
